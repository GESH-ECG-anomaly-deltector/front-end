import React, { useState } from "react";
import { Link } from "react-router-dom";

import Logo from '../assets/icons/Logo'

const NavBar = () => {
    return ( 
        <div className = "bg-white flex justify-between items-center px-[2rem] py-[1.25rem] whitespace-nowrap">
            <Link to='/' className="flex gap-[0.5rem] items-center w-fit h-fit">
                <div className="flex justify-center items-center h-[2.25rem] w-[2.25rem] flex-shrink-0">
                    <Logo width={36} height={36} className={""}/>
                </div>
                <div className="flex flex-col">
                    <span className="font-vazir font-extrabold text-[1.125rem]">گِش</span>
                    <span className="font-vazir font-regular text-[0.625rem] text-text-muted-foreground">تحلیل هوشمند نوار قلب</span>
                </div>
            </Link>
            <div className="flex font-vazir font-regular gap-[1.5rem] justify-center items-center text-[0.875rem] text-text-muted-foreground">
                <a href="#how-it-works">نحوه کار</a>
                <a href="#start">شروع</a>
            </div>
            <div className="flex gap-[0.5rem] h-fit w-fit">
                <a href="#start" className="bg-primary flex font-vazir font-medium h-[2rem] items-center justify-center pb-[0.525rem] pt-[0.475rem] px-[0.75rem] rounded-full text-[0.75rem] text-background w-fit">
                    شروع کنید
                </a>
                <Link to="/login-signup?mode=login" className="flex font-vazir font-medium h-[2rem] items-center justify-center pb-[0.525rem] pt-[0.475rem] px-[0.75rem] text-[0.75rem]">ورود</Link>
            </div>
        </div>
     );
}
 
export default NavBar;
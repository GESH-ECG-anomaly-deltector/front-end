const UserIcon = () => {
    return (
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M10.0002 10.8333C12.3013 10.8333 14.1668 8.96785 14.1668 6.66667C14.1668 4.36548 12.3013 2.5 10.0002 2.5C7.69898 2.5 5.8335 4.36548 5.8335 6.66667C5.8335 8.96785 7.69898 10.8333 10.0002 10.8333Z" stroke="currentColor" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M16.6668 17.5C16.6668 15.7319 15.9645 14.0362 14.7142 12.786C13.464 11.5358 11.7683 10.8334 10.0002 10.8334C8.23205 10.8334 6.53636 11.5358 5.28612 12.786C4.03588 14.0362 3.3335 15.7319 3.3335 17.5" stroke="currentColor" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>


      );
}
 
export default UserIcon;
/**
 * وضعیت کاربر تو جدول مدیریت، با وضعیت رکورد ECG (که تو diagnosisHelpers.js
 * هست) فرق می‌کنه - این یه دامنه‌ی جداست، برای همین یه تابع مستقل داره.
 *
 * برای پزشک‌ها معمولاً "pending" | "approved" | "rejected" میاد.
 * برای بیمارها (بسته به اینکه بک‌اند دقیقاً چی برمی‌گردونه) معمولاً یا
 * "PENDING_NATIONAL_CODE" | "ACTIVE" (اگه از enum جاوا مستقیم بیاد)
 * یا نسخه‌ی lowercase‌شده‌ست. هر دو حالت رو پوشش دادیم.
 *
 * نکته: اگه بعد از تست، دیدی لیبل درستی نمایش داده نمیشه، مقدار واقعی
 * user.status رو با console.log(user) چک کن و مقدار دقیقش رو بهم بگو
 * تا این mapping رو باهاش هماهنگ کنم.
 */
export const getUserStatusLabel = (status) => {
    const normalized = (status || '').toString().toUpperCase();
    switch (normalized) {
        case 'APPROVED':
        case 'ACTIVE':
            return 'فعال';
        case 'PENDING':
        case 'PENDING_NATIONAL_CODE':
            return 'در انتظار تایید';
        case 'REJECTED':
        case 'INACTIVE':
            return 'غیرفعال';
        default:
            return 'نامشخص';
    }
};

export const getUserStatusColorClass = (status) => {
    const normalized = (status || '').toString().toUpperCase();
    switch (normalized) {
        case 'APPROVED':
        case 'ACTIVE':
            return 'bg-success/15 text-success';
        case 'PENDING':
        case 'PENDING_NATIONAL_CODE':
            return 'bg-warning/15 text-warning';
        case 'REJECTED':
        case 'INACTIVE':
            return 'bg-text-muted-foreground/15 text-text-muted-foreground';
        default:
            return 'bg-text-muted-foreground/15 text-text-muted-foreground';
    }
};